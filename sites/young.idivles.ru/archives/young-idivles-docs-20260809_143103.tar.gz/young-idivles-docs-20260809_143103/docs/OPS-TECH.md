# Ops TECH — kill-switch modules

## Access

1. Set in `.env` (also passed into `web` via docker-compose):

```bash
TECH_EMAIL=tech-ops@sochi.local
TECH_BOOTSTRAP_PASSWORD='…strong…'
# or TECH_PASSWORD_HASH='$2b$…'
# emergency: MODULE_FLAGS_FORCE_ON=1
```

2. Open `/login?staff=1`, sign in with TECH email.
3. First login creates the user with role `TECH` if missing.
4. Home for TECH: **`/ops`** (404 for everyone else).

Credentials generated on install (if any): `docs/OPS-TECH-CREDENTIALS.txt` (keep private).

## Flags

Stored in `SiteSettings.moduleFlagsJson`. Missing key = **on**.
`TECH` always bypasses. Priority: flag OFF beats admin settings ON.

Keys: registration, messaging, events, tickets_scan, places, gallery, projects, clubs, spaces, programs, vacancies, contests, friends, games, news, portfolio, maintenance.

## Behaviour

- Proxy + `/api/public/status` → redirect `/unavailable?m=…` or API `503 MODULE_DISABLED`.
- TECH hidden from ADMIN user lists (`role !== TECH`).
- Audit: `LoginEvent` kind `OPS_FLAGS`.
